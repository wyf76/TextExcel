package textExcel;

public class FormulaCell implements Cell {
    private String input;

    public FormulaCell(String input) {
        this.input = input;
    }

    @Override
    public String abbreviatedCellText() {
        return Double.toString(getDoubleValue());
    }

    @Override
    public String fullCellText() {
        return "(" + input+ ")";
    }
    public double getDoubleValue() {
    	String[] str = input.split(" ");
    	double result = Double.parseDouble(str[0]);
    	for (int i = 1; i <str.length; i+=2) {
    		String operator = str[i];
    		double value = Double.parseDouble(str[i+1]);
    		
    		if(operator.equals("+")) 
    			result += value;
    		else if(operator.equals("-"))
    			result -= value;
    		else if(operator.equals("*"))
    			result *=value;
    		else if(operator.equals("/"))
    			result /=value;
    	}
    	return result;
    }
    
}