package textExcel;

public class FormulaCell extends RealCell {
	private Spreadsheet sheet;
    public FormulaCell(String input, Spreadsheet sheet) {
    	super(input);
    	this.sheet =sheet;
    }

    public String abbreviatedCellText() {
        String value = Double.toString(getDoubleValue());
        if (value.length() > 10) {
            return value.substring(0, 10);
        }
        while (value.length() < 10) {
            value += " ";
        }
        return value;
    } 

    public String fullCellText() {
        return super.fullCellText();
    }
	public double getDoubleValue() {
        String[] str = super.fullCellText().split(" ");
        for (int i = 1; i < str.length - 1; i += 2) {
            String operand = str[i];
            if (operand.toUpperCase().matches("[A-Z]+[0-9]+")) {
                // The operand is a cell reference
                Location loc = new SpreadsheetLocation(operand);
                Cell cell = sheet.getCell(loc);                       
                if (cell instanceof Cell) {
                    double value = ((RealCell) cell).getDoubleValue();
                    str[i] = Double.toString(value);
                } else {
                    // The referenced cell is not a RealCell
                    str[i] = "";
                }
            }
        }
        String modifiedInput = String.join(" ", str);
        if (modifiedInput.startsWith("SUM")) {
            String[] operands = modifiedInput.substring(4).split(" ");
            double sum = 0;
            for (String i : operands) {
                Location loc = new SpreadsheetLocation(i);
                Cell cell = sheet.getCell(loc);
                if (cell instanceof RealCell) {
                    sum += ((RealCell) cell).getDoubleValue();
                }
            }
            return sum;
        } else if (modifiedInput.startsWith("AVG")) {
            String[] operands = modifiedInput.substring(4).split(" ");
            double sum = 0;
            int count = 0;
            for (String i : operands) {
                Location loc = new SpreadsheetLocation(i);
                Cell cell = sheet.getCell(loc);
                if (cell instanceof RealCell) {
                    sum += ((RealCell) cell).getDoubleValue();
                    count++;
                }
            }
            return (count > 0) ? (sum / count) : 0;
        } else {
            // The formula is a basic arithmetic expression
            double result = 0;
            for (int i = 0; i < str.length; i++) {
                String token = str[i];
                if (isOperator(token)) {
                    double operand1 = Double.parseDouble(str[i - 1]);
                    double operand2 = Double.parseDouble(str[i + 1]);
                    result = applyOperator(token, operand1, operand2);
                    str[i + 1] = Double.toString(result);
                }
            }
            return result;
        }
    }

    private boolean isOperator(String token) {
        return token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/");
    }

    private double applyOperator(String operator, double operand1, double operand2) {
        switch (operator) {
            case "+":
                return operand1 + operand2;
            case "-":
                return operand1 - operand2;
            case "*":
                return operand1 * operand2;
            case "/":
                return operand1 / operand2;
            default:
                throw new IllegalArgumentException("Invalid operator: " + operator);
        }
    }
}