package textExcel;

public class FormulaCell extends RealCells{
	private String formula;
	public FormulaCell(String input) {
		super(input);
	}
	public double getDoubleValue() {
		return 0;
	}
}
