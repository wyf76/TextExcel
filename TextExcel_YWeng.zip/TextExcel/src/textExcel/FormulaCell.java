package textExcel;

public class FormulaCell extends RealCell {
    private String input;

    public FormulaCell(String input) {
    	super(input);
    	this.input = input;
    }

    public String abbreviatedCellText() {
        String value = Double.toString(getDoubleValue());
        if (value.length() > 10) {
            return value.substring(0, 10);
        }
        while (value.length() < 10) {
            value += " ";
        }
        return value;
    }

    public String fullCellText() {
        return "(" + input+ ")";
    }
    public double getDoubleValue() {
        String noP = input.substring(input.indexOf("(") + 1, input.indexOf(")"));
        String[] str = noP.split(" ");
        
        double result = Double.parseDouble(str[0]);
        for (int i = 1; i < str.length; i += 2) {
            String operator = str[i];
            double value = 0;
            if (i + 1 < str.length && !str[i + 1].isEmpty()) {
                value = Double.parseDouble(str[i + 1]);
            }
            if (operator.equals("+")) 
                result += value;
            else if (operator.equals("-"))
                result -= value;
            else if (operator.equals("*"))
                result *= value;
            else if (operator.equals("/"))
                result /= value;
        }
        return result;
    }
}