package textExcel;

public abstract class RealCell implements Cell{
	public String input;
	
	public RealCell(String input) {
		this.input = input;
	}
	@Override
	public String abbreviatedCellText() {
	    String valueString = Double.toString(getDoubleValue());
	    if (valueString.length() > 10) {
	    	return valueString.substring(0, 10);
	    }
	    return valueString + "          ".substring(valueString.length());
	}
	@Override
	public String fullCellText() {
		return input;
	}

	public abstract double getDoubleValue();
}

