package textExcel;

public abstract class RealCell implements Cell{
	private String input;
	
	public RealCell(String input) {
		this.input = input;
	}
	@Override
	public String abbreviatedCellText() {
		String text = getDoubleValue() +"";
		if (text.length()>10){
			return text.substring(0,10);
		}else {
			while (text.length()<10) {
				text+=" ";
			}
			return text;
		}	
	}
	@Override
	public String fullCellText() {
		return input;
	}

	public abstract double getDoubleValue();
}

