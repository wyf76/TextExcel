package textExcel;

public class ValueCell extends RealCell {
    private double doubleValue;

    public ValueCell(String inputString) {
        super(inputString);
        doubleValue = Double.parseDouble(inputString);
    }

    @Override
    public double getDoubleValue() {
        return doubleValue;
    }
}