package textExcel;

public class ValueCell extends RealCells{
	private double value;
	public ValueCell(String input) {
		super(input);
	    this.value = Double.parseDouble(input);
	}
	@Override
	public String fullCellText() {
		return input.substring(0, input.length()-1) + "          ";
	}
	@Override
	public double getDoubleValue() {
		String shortValue = Double.toString(value).substring(0, input.length()-1)+ "          ";
		return Double.parseDouble(shortValue);
	}
}
