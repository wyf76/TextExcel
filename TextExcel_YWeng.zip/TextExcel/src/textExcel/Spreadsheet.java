package textExcel;
/*Yufan
 * February 22, 2023
 * class definition for excel
 */
// Update this file with your own code.

public class Spreadsheet implements Grid
{
    private int rows = 20;
    private int columns =12;
    private Cell[][] sheet = new Cell[rows][columns];

    public Spreadsheet() {
        sheet = new Cell[rows][columns];
        clearSheet();
    }

    private void clearSheet() {
        for(int r = 0; r < rows; r++) {
            for(int c =0; c <columns; c++) {
                sheet[r][c] = new EmptyCell();
            }
        }
    }

    @Override
    public int getRows() {
        return rows;
    }

    @Override
    public int getCols() {
        return columns;
    }

    @Override
    public Cell getCell(Location loc) {
        return sheet[loc.getRow()][loc.getCol()];
    }

    @Override
    public String processCommand(String command) {
        String[] parts = command.split(" ", 3);
        if (parts.length == 1 && parts[0].equalsIgnoreCase("clear")) {
            clearSheet();
            return getGridText();
        } else if (parts.length == 2 && parts[0].equalsIgnoreCase("clear")) {
            Location loc = new SpreadsheetLocation(parts[1]);
            sheet[loc.getRow()][loc.getCol()] = new EmptyCell();
            return getGridText();
        } else if (parts.length >= 3 && (parts[1].equals("="))) {
                String value = parts[2];
                Location loc = new SpreadsheetLocation(parts[0]);
                if (value.charAt(0) == '\"' && value.charAt(value.length() - 1) == '\"') {
                    sheet[loc.getRow()][loc.getCol()] = new TextCell(value);
                }else if (value.endsWith("%")) {
                    sheet[loc.getRow()][loc.getCol()] = new PercentCell(value);
                } else if(parts.length == 3 && parts[1].equals("=") && parts[2].startsWith("(") && parts[2].endsWith(")")) {
                    sheet[loc.getRow()][loc.getCol()] = new FormulaCell(parts[2]);
                    return getGridText();
        		}else {
                    sheet[loc.getRow()][loc.getCol()] = new ValueCell(value);
                }
                return getGridText();
        }else if(parts.length ==1) {
            Location loc = new SpreadsheetLocation(parts[0]);
            return getCell(loc).fullCellText();
        }
        return "Type a valid command: ";
    }
	@Override
	public String getGridText() {
	    String gridText = "   |";  //create 3 spaces before character
	    for (char c = 'A'; c < 'A' + columns; c++) { // create headline from a to l
	        gridText += c + "         |";
	    }
	    gridText += "\n"; //next line
	    for (int i = 0; i < rows; i++) {
	        if (i + 1 < 10) {
	            gridText += (i + 1) + "  |"; //first 9 number with 2 spaces after
	        }else {
	            gridText += (i + 1) + " |"; //other with 1 spaces after
	        }
	        for (int j = 0; j < columns; j++) {
	            gridText += sheet[i][j].abbreviatedCellText()+"|"; // create 10 spaces for range
	        }
	        gridText += "\n"; //continue to next line
	    }
	    return gridText;
	}
}