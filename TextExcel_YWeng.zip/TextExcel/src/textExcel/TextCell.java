package textExcel;

public class TextCell implements Cell{
	private String text;
	
	public TextCell (String text) {
		this.text=text;
	}
    @Override
	public String fullCellText() {
		return text;
	}
    @Override
	public String abbreviatedCellText() {
    	String abbreviated = text.substring(0, text.length()-1) + "          ";
        if(abbreviated.length() >10) {
        	abbreviated = abbreviated.substring(0,10);
        }
        return abbreviated;
    }
}
