package textExcel;

public class TextCell implements Cell{
	private String text;
	
	public TextCell (String text) {
		this.text=text;
	}
    @Override
	public String fullCellText() {
		return text;
	}
    @Override
	public String abbreviatedCellText() {
    	String abbreviated=text;
    	if(text.length()<10) {
    		abbreviated = text.substring(0,10);
    	}else {
    			int numSpace = 10 -text.length();
    			for(int i = 0; i< numSpace; i++) {
    				abbreviated +=" ";
    			}
    		}
    	return abbreviated;
    	}
    }
