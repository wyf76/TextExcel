package textExcel;
import java.io.FileNotFoundException;
import java.util.Scanner;

// Update this file with your own code.

public class TextExcel
{

	public static void main(String[] args)
	{
	    // Add your command loop here
		Spreadsheet spreadsheet = new Spreadsheet();
		Scanner scanner = new Scanner(System.in);
		boolean end = true;
		String input = "";
		System.out.println(spreadsheet.getGridText());
		while(end != false) {
			System.out.println("Enter \"quit\" to quit");
			while(!input.equals("quit")) {
				input = scanner.nextLine();
				System.out.println(spreadsheet.processCommand(input));
				
			}
			end=false;
		}
		scanner.close();
	}

}
