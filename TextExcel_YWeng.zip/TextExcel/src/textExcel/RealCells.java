package textExcel;

public abstract class RealCells implements Cell{
	public String input;
	
	public RealCells(String input) {
		this.input = input;
	}
	@Override
	public String abbreviatedCellText() {
	    String valueString = Double.toString(getDoubleValue());
	    if (valueString.length() > 10) {
	    	return valueString.substring(0, 10);
	    }
	    return valueString + "          ".substring(valueString.length());
	}
	@Override
	public String fullCellText() {
		return input;
	}

	public abstract double getDoubleValue();
}

