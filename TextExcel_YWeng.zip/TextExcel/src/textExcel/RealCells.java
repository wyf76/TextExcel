package textExcel;

public abstract class RealCells implements Cell{
	public String input;
	
	public RealCells(String input) {
		this.input = input;
	}
	@Override
	public String fullCellText() {
		return input;
	}
	@Override
	public String abbreviatedCellText() {
    	String abbreviated = input.substring(0, input.length()-1) + "           ";
        if(abbreviated.length() >10) {
        	abbreviated = abbreviated.substring(0,10);
        }
        return abbreviated;
    }
	public abstract double getDoubleValue();
}
