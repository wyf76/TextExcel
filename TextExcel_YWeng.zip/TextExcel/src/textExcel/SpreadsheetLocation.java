package textExcel;
/*Yufan Weng
 * February 22, 2023
 */
//Update this file with your own code.

public class SpreadsheetLocation implements Location
{
	private int row;
	private int column;
        //constructor
    public SpreadsheetLocation(String cellName)
    {
        // TODO: Fill this out with your own code
    	column = cellName.substring(0,1).toUpperCase().charAt(0) -'A';
    	row = Integer.parseInt(cellName.substring(1))-1;
    }
    @Override
    public int getRow()
    {
        // TODO Auto-generated method stub
        return row;
    }

    @Override
    public int getCol()
    {
        // TODO Auto-generated method stub
        return column;
    }
}
