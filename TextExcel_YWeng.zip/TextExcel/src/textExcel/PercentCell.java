package textExcel;
public class PercentCell extends RealCell {
	private double decimalValue;
    public PercentCell(String input) {
        super(input);
    	double value = Double.parseDouble(super.fullCellText().replace("%", "")) / 100.0;
        this.decimalValue = value;
    }

    @Override
    public double getDoubleValue() {
    	double value = Double.parseDouble(super.fullCellText().replace("%", "")) / 100.0;
        return value;
    }
    @Override
	public String abbreviatedCellText() {
        String formatted = "" + (int) (decimalValue * 100) + "%" + "          ";
        return formatted.substring(0,10);
    }

    @Override
    public String fullCellText() {
        return Double.toString(getDoubleValue());
    }
}